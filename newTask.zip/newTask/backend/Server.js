const express = require("express");
const mongoose = require("mongoose");
const axios = require("axios");
const cors = require("cors");

const app = express();
const PORT = 5000;

// Middleware
app.use(express.json());
app.use(cors());

// MongoDB Connection
const DB_URI = "mongodb://localhost:27017/transactionsDB"; // Replace with your MongoDB URI
mongoose
  .connect(DB_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log("MongoDB connected"))
  .catch((err) => console.error("MongoDB connection error:", err));

// Schema and Model
const transactionSchema = new mongoose.Schema({
    dateOfSale: { type: Date, required: true },  // Ensure this is a Date type
    amount: { type: Number, required: true },
    status: { type: String, required: true },
    // Add other fields as necessary
  });
  
  const Transaction = mongoose.model('Transaction', transactionSchema);

// API to initialize database
app.get('/api/dashboard/statistics', (req, res) => {
    // Mock response
    res.json({
        totalSales: 1000,
        totalUsers: 50,
        totalOrders: 200,
        revenue: 50000
    });
});


app.get("/api/initialize", async (req, res) => {
  try {
    const response = await axios.get(
      "https://s3.amazonaws.com/roxiler.com/product_transaction.json"
    );
    const products = response.data;

    await Transaction.deleteMany(); // Clear existing data
    await Transaction.insertMany(products); // Insert new data
    res.status(200).send({ message: "Database initialized successfully" });
  } catch (error) {
    console.error("Initialization Error:", error);
    res.status(500).send({ error: "Failed to initialize database" });
  }
});

// API to list transactions with search and pagination
app.get("/api/transactions", async (req, res) => {
    // Destructure query parameters
    let { month, search = "", page = 1, perPage = 10 } = req.query;
  
    // Validate month
    if (month < 1 || month > 12) {
      return res.status(400).send({ error: "Invalid month parameter" });
    }
  
    // Sanitize month, page, and perPage (convert them to numbers)
    month = parseInt(month, 10); // Ensure month is a number
    page = parseInt(page, 10) || 1; // Ensure page is a number or set to 1 by default
    perPage = parseInt(perPage, 10) || 10; // Ensure perPage is a number or set to 10 by default
  
    // Set date range based on month (ignore the year part for flexibility)
    const currentYear = new Date().getFullYear();
    const startOfMonth = new Date(currentYear, month - 1, 1);
    const endOfMonth = new Date(currentYear, month, 1);
  
    // Ensure the dates are valid
    if (isNaN(startOfMonth.getTime()) || isNaN(endOfMonth.getTime())) {
      return res.status(400).send({ error: "Invalid date range" });
    }
  
    // Build query to fetch transactions
    const query = {
      dateOfSale: { $gte: startOfMonth, $lt: endOfMonth },
      $or: [
        { title: { $regex: search, $options: "i" } },
        { description: { $regex: search, $options: "i" } },
        { price: isNaN(parseFloat(search)) ? undefined : parseFloat(search) },
      ],
    };
  
    // Remove price condition if it is undefined
    if (query.$or[2].price === undefined) {
      query.$or.pop();
    }
  
    try {
      const transactions = await Transaction.find(query)
        .skip((page - 1) * perPage) 
        .limit(Number(perPage)); 
  
      const total = await Transaction.countDocuments(query);
  
      res.status(200).send({ transactions, total });
    } catch (error) {
      console.error("Fetch Transactions Error:", error);
      res.status(500).send({ error: "Failed to fetch transactions" });
    }
  });
  
  
  
  

// API for statistics
app.get("/api/statistics", async (req, res) => {
  const { month } = req.query;

  // Validate month
  if (month < 1 || month > 12) {
    return res.status(400).send({ error: "Invalid month parameter" });
  }

  // Set date range based on month, regardless of year
  const startOfMonth = new Date(new Date().getFullYear(), month - 1, 1);
  const endOfMonth = new Date(new Date().getFullYear(), month, 1);

  try {
    const totalSale = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lt: endOfMonth } } },
      { $group: { _id: null, total: { $sum: "$price" } } },
    ]);

    const soldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lt: endOfMonth },
      sold: true,
    });

    const notSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: startOfMonth, $lt: endOfMonth },
      sold: false,
    });

    res.status(200).send({
      totalSale: totalSale[0]?.total || 0,
      soldItems,
      notSoldItems,
    });
  } catch (error) {
    console.error("Fetch Statistics Error:", error);
    res.status(500).send({ error: "Failed to fetch statistics" });
  }
});

// API for bar chart
app.get("/api/bar-chart", async (req, res) => {
  const { month } = req.query;

  // Validate month
  if (month < 1 || month > 12) {
    return res.status(400).send({ error: "Invalid month parameter" });
  }

  // Set date range based on month, regardless of year
  const startOfMonth = new Date(new Date().getFullYear(), month - 1, 1);
  const endOfMonth = new Date(new Date().getFullYear(), month, 1);

  try {
    const priceRanges = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lt: endOfMonth } } },
      {
        $bucket: {
          groupBy: "$price",
          boundaries: [
            0, 100, 200, 300, 400, 500, 600, 700, 800, 900, Infinity,
          ],
          default: "901-above",
          output: { count: { $sum: 1 } },
        },
      },
    ]);

    res.status(200).send(priceRanges);
  } catch (error) {
    console.error("Fetch Bar Chart Error:", error);
    res.status(500).send({ error: "Failed to fetch bar chart data" });
  }
});

// API for pie chart
app.get("/api/pie-chart", async (req, res) => {
  const { month } = req.query;

  // Validate month
  if (month < 1 || month > 12) {
    return res.status(400).send({ error: "Invalid month parameter" });
  }

  // Set date range based on month, regardless of year
  const startOfMonth = new Date(new Date().getFullYear(), month - 1, 1);
  const endOfMonth = new Date(new Date().getFullYear(), month, 1);

  try {
    const categoryData = await Transaction.aggregate([
      { $match: { dateOfSale: { $gte: startOfMonth, $lt: endOfMonth } } },
      { $group: { _id: "$category", count: { $sum: 1 } } },
    ]);

    res.status(200).send(categoryData);
  } catch (error) {
    console.error("Fetch Pie Chart Error:", error);
    res.status(500).send({ error: "Failed to fetch pie chart data" });
  }
});

// API to fetch combined data
app.get("/api/combined-data", async (req, res) => {
  const { month } = req.query;

  // Validate month
  if (month < 1 || month > 12) {
    return res.status(400).send({ error: "Invalid month parameter" });
  }

  try {
    // Fetch all required data concurrently
    const [transactions, stats, barChart, pieChart] = await Promise.all([
      Transaction.find({
        dateOfSale: {
          $gte: new Date(new Date().getFullYear(), month - 1, 1),
          $lt: new Date(new Date().getFullYear(), month, 1),
        },
      }).limit(10),
      // Fetch statistics
      Transaction.aggregate([
        { $match: { dateOfSale: { $gte: new Date(new Date().getFullYear(), month - 1, 1), $lt: new Date(new Date().getFullYear(), month, 1) } } },
        { $group: { _id: null, total: { $sum: "$price" } } },
      ]),
      // Fetch bar chart data
      Transaction.aggregate([
        { $match: { dateOfSale: { $gte: new Date(new Date().getFullYear(), month - 1, 1), $lt: new Date(new Date().getFullYear(), month, 1) } } },
        {
          $bucket: {
            groupBy: "$price",
            boundaries: [0, 100, 200, 300, 400, 500, 600, 700, 800, 900, Infinity],
            default: "901-above",
            output: { count: { $sum: 1 } },
          },
        },
      ]),
      // Fetch pie chart data
      Transaction.aggregate([
        { $match: { dateOfSale: { $gte: new Date(new Date().getFullYear(), month - 1, 1), $lt: new Date(new Date().getFullYear(), month, 1) } } },
        { $group: { _id: "$category", count: { $sum: 1 } } },
      ]),
    ]);

    // Process stats
    const totalSale = stats[0]?.total || 0;
    const soldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: new Date(new Date().getFullYear(), month - 1, 1), $lt: new Date(new Date().getFullYear(), month, 1) },
      sold: true,
    });
    const notSoldItems = await Transaction.countDocuments({
      dateOfSale: { $gte: new Date(new Date().getFullYear(), month - 1, 1), $lt: new Date(new Date().getFullYear(), month, 1) },
      sold: false,
    });

    res.status(200).send({
      transactions,
      statistics: { totalSale, soldItems, notSoldItems },
      barChart,
      pieChart,
    });
  } catch (error) {
    console.error("Fetch Combined Data Error:", error);
    res.status(500).send({ error: "Failed to fetch combined data" });
  }
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
