import React, { useState, useEffect } from "react";
import BarChart from "../components/Dashboard/BarChart";
import Loader from "../components/Loader";
import ErrorBoundary from "../pages/ErrorBoundary";
import "../components/Dashboard/styles/Dashboard.css";

function Dashboard() {
    const chartData = {
        labels: ['January', 'February', 'March', 'April', 'May'],
        datasets: [
            {
                label: 'Revenue',
                data: [300, 500, 700, 800, 1200],
                backgroundColor: [
                    'rgba(75, 192, 192, 0.2)',
                    'rgba(54, 162, 235, 0.2)',
                    'rgba(255, 206, 86, 0.2)',
                    'rgba(153, 102, 255, 0.2)',
                    'rgba(255, 99, 132, 0.2)',
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(153, 102, 255, 1)',
                    'rgba(255, 99, 132, 1)',
                ],
                borderWidth: 1,
            },
        ],
    };

    const [statistics, setStatistics] = useState(null);
    const [error, setError] = useState(null);

    const fetchData = async () => {
        try {
            const response = await fetch('http://localhost:5000/api/dashboard/statistics');
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            const data = await response.json();
            setStatistics(data);
        } catch (err) {
            console.error('Error fetching data:', err);
            setError('Failed to fetch dashboard data');
        }
    };

    useEffect(() => {
        fetchData();
    }, []);

    if (error) {
        return <div>Error: {error}</div>;
    }

    if (!statistics) {
        return <Loader/>;
    }

  return (
    <div className="dashboard">
      <ErrorBoundary>
      <h1>Dashboard</h1>
            <div>Total Sales: {statistics.totalSales}</div>
            <div>Total Users: {statistics.totalUsers}</div>
            <div>Total Orders: {statistics.totalOrders}</div>
            <div>Revenue: {statistics.revenue}</div>        <div className="chart">
          <BarChart data={chartData} />
        </div>
      </ErrorBoundary>
    </div>
  );
}

export default Dashboard;
