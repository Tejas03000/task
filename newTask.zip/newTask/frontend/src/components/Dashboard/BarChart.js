import React, { useEffect, useRef } from "react";
import { Chart, registerables } from "chart.js";

Chart.register(...registerables);

const BarChart = ({ data, options }) => {
  const chartRef = useRef(null); // Reference to the canvas DOM element
  const chartInstance = useRef(null); // Persistent Chart.js instance reference

  useEffect(() => {
    if (chartRef.current) {
      // Destroy the existing chart if it exists to avoid canvas reuse issues
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }

      // Initialize the chart instance
      chartInstance.current = new Chart(chartRef.current, {
        type: "bar", // Bar chart type
        data: data,
        options: options,
      });
    }

    // Cleanup: Destroy the chart on component unmount
    return () => {
      if (chartInstance.current) {
        chartInstance.current.destroy();
      }
    };
  }, [data, options]); // Dependencies to reinitialize the chart

  return <canvas ref={chartRef} />;
};

export default BarChart;
