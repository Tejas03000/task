import React, { useState, useEffect } from 'react';

const TransactionTable = () => {
  const [transactions, setTransactions] = useState([]);


  useEffect(() => {
    // Fetching transactions data from the backend API
    const fetchTransactions = async () => {
      const month = 5; 
      const search = ''; 
      const page = 1;
      const perPage = 10;
    
      try {
        const response = await fetch(`http://localhost:5000/api/transactions?month=${month}&search=${search}&page=${page}&perPage=${perPage}`);
        const data = await response.json();
        if (response.ok) {
          setTransactions(data.transactions);
        } else {
          console.error("Error fetching transactions:", data.error);
        }
      } catch (error) {
        console.error("Fetch Transactions Error:", error);
      }
    };
    
    
    fetchTransactions();
  }, []); 

  return (
    <div>
      <h2>Transaction Table</h2>
      <table>
        <thead>
          <tr>
            <th>ID</th>
            <th>Date</th>
            <th>Amount</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {transactions.map(transaction => (
            <tr key={transaction.id}>
              <td>{transaction.id}</td>
              <td>{transaction.date}</td>
              <td>{transaction.amount}</td>
              <td>{transaction.status}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default TransactionTable;
