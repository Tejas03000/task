import React from "react";
import "../Dashboard/styles/Dashboard.css";

function StatisticsCard({ title, value }) {
  return (
    <div className="stats-card">
      <h3>{title}</h3>
      <p>{value}</p>
    </div>
  );
}

export default StatisticsCard;
