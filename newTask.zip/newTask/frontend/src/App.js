import React from 'react';
import Dashboard from './pages/Dashboard';  // Import Dashboard
import TransactionsTable from './components/Dashboard/TransactionsTable';

const App = () => {
    return (
        <div className="App">
            <Dashboard />  {/* Main Dashboard Component */}
            <TransactionsTable/>
        </div>
    );
};

export default App;
